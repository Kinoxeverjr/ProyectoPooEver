
package co.edu.ude.poo.LavaderoDeCarros;

public class Principal {

}
