package co.edu.ude.poo.LavaderoDeCarros.modelo.crud;

import co.edu.ude.poo.LavaderoDeCarros.modelo.entidades.Servicio;
import java.util.ArrayList;
import java.util.List;


public class ServicioCrud {
    private static List<Servicio> listaServicios = new ArrayList<>();

        public int agregarServicio (Servicio servicio) throws Exception {
            for (Servicio s : listaServicios){
                if (servicio.getNombreDelServicio() == s.getNombreDelServicio() ) {
                    throw new Exception ("El serivicio " + s.getNombreDelServicio() + "ya existe");
                }
            }
            listaServicios.add(servicio);
            return listaServicios.size();
            
    }

public Servicio buscarServicio (String nombreDelServicio) throws Exception {
    Servicio servicio = null;
    for (Servicio s : listaServicios) {
        if (s.getNombreDelServicio() == nombreDelServicio) {
            servicio = s;
            break;
            }
    }
    if (servicio == null){
    throw new Exception ("El serviccio " + nombreDelServicio + "ya existe");
    }
    return servicio;
        
}

public void borrarServicio (String nombreDelServicio) throws Exception {
    Servicio servicio = null;
    for (Servicio s : listaServicios) {
        if (s.getNombreDelServicio() == nombreDelServicio) {
            servicio = s;
            break;
        }
    }
    if (servicio == null) {
        throw new Exception ("El servicio " + nombreDelServicio + "no esta registrado");
        
    }
    listaServicios.remove(servicio);
  }
        public void actualizarServicio(String nombreDelServicio, Servicio nuevoServicio) throws Exception {
    Servicio servicioOriginal = buscarServicio(nombreDelServicio);
    if (servicioOriginal != null) {
            servicioOriginal.setPrecioDelServicio(nuevoServicio.getPrecioDelServicio());
            servicioOriginal.setTiempoDeDuracionMin(nuevoServicio.getTiempoDeDuracionMin());
            servicioOriginal.setDescripcionDelServcio(nuevoServicio.getDescripcionDelServcio());
        } else {
            throw new Exception("SERVICIO NO SE PUDO ACTUALIZAR");
        }
    }


}
  

