package co.edu.ude.poo.LavaderoDeCarros.modelo.crud;

import co.edu.ude.poo.LavaderoDeCarros.modelo.entidades.Trabajador;
import java.util.ArrayList;
import java.util.List;


public class TrabajadorCrud {
    private static List<Trabajador> listaTrabajadores = new ArrayList<>();

        public int agregarTrabajador (Trabajador trabajador) throws Exception {
            for (Trabajador t : listaTrabajadores){
                if (trabajador.getId() == t.getId() ) {
                    throw new Exception ("El trabajador con ID: "+ t.getId() + "ya existe");
                }
            }
            listaTrabajadores.add(trabajador);
            return listaTrabajadores.size();
            
    }

public Trabajador buscarTrabajador (int Id) throws Exception {
    Trabajador trabajador = null;
    for (Trabajador t : listaTrabajadores) {
        if (t.getId() == Id) {
            trabajador = t;
            break;
            }
    }
    if (trabajador == null){
    throw new Exception ("El trabajador con Id: " + Id + "ya existe");
    }
    return trabajador;
        
}

public void borrarTrabajador ( int Id) throws Exception {
    Trabajador trabajador = null;
    for (Trabajador t : listaTrabajadores) {
        if (t.getId() == Id) {
            trabajador = t;
            break;
        }
    }
    if (trabajador == null) {
        throw new Exception ("El trabajador con Id: " + Id + "no esta registrado");
        
    }
    listaTrabajadores.remove(trabajador);
  }
public void actualizarTrabajador(int id, Trabajador nuevoTrabajador) throws Exception {
    Trabajador trabajadorOriginal = buscarTrabajador(id);
    if (trabajadorOriginal != null) {
        trabajadorOriginal.setNombre(nuevoTrabajador.getNombre());
        trabajadorOriginal.setApellido(nuevoTrabajador.getApellido());
        trabajadorOriginal.setFechaNacimiento(nuevoTrabajador.getFechaNacimiento());
        trabajadorOriginal.setSalario(nuevoTrabajador.getSalario());
        trabajadorOriginal.setPuesto(nuevoTrabajador.getPuesto());
    } else {
        throw new Exception("TRABAJADOR NO SE PUDO ACTUALIZAR");
    }
}
}

