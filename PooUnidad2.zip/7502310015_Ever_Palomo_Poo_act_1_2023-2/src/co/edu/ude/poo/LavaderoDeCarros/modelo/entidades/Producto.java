package co.edu.ude.poo.LavaderoDeCarros.modelo.entidades;

import java.time.LocalDate;

// Clase Producto
public class Producto {
    private String nombreProducto;
    private double precioDelProducto;
    private int numeroDeProducto;
    private LocalDate fechaDeVencimiento;

    // Constructor
    public Producto(String nombreProducto, double precioDelProducto, int numeroDeProducto, LocalDate fechaDeVencimiento) {
        this.nombreProducto = nombreProducto;
        this.precioDelProducto = precioDelProducto;
        this.numeroDeProducto = numeroDeProducto;
        this.fechaDeVencimiento = fechaDeVencimiento;
    }

    // Métodos getters y setters
    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public double getPrecioDelProducto() {
        return precioDelProducto;
    }

    public void setPrecioDelProducto(double precioDelProducto) {
        this.precioDelProducto = precioDelProducto;
    }

    public int getNumeroDeProducto() {
        return numeroDeProducto;
    }

    public void setNumeroDeProducto(int numeroDeProducto) {
        this.numeroDeProducto = numeroDeProducto;
    }

    public LocalDate getFechaDeVencimiento() {
        return fechaDeVencimiento;
    }

    public void setFechaDeVencimiento(LocalDate fechaDeVencimiento) {
        this.fechaDeVencimiento = fechaDeVencimiento;
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Producto{");
        sb.append("NombreProducto=").append(nombreProducto);
        sb.append(", PrecioDelProducto=").append(precioDelProducto);
        sb.append(", NumeroDeProducto=").append(numeroDeProducto);
        sb.append(", FechaDeVencimiento=").append(fechaDeVencimiento);
        sb.append('}');
        return sb.toString();
    }

    
}
