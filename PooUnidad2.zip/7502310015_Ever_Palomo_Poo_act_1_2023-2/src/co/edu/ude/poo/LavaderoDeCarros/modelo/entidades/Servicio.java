package co.edu.ude.poo.LavaderoDeCarros.modelo.entidades;


public class Servicio {
    
    private String NombreDelServicio;
    private double PrecioDelServicio;
    private int TiempoDeDuracionMin;
    private String DescripcionDelServcio;

    public Servicio() {
    }

    public Servicio(String NombreDelServicio, double PrecioDelServicio, int TiempoDeDuracionMin, String DescripcionDelServcio) {
        this.NombreDelServicio = NombreDelServicio;
        this.PrecioDelServicio = PrecioDelServicio;
        this.TiempoDeDuracionMin = TiempoDeDuracionMin;
        this.DescripcionDelServcio = DescripcionDelServcio;
    }

    public String getNombreDelServicio() {
        return NombreDelServicio;
    }

    public void setNombreDelServicio(String NombreDelServicio) {
        this.NombreDelServicio = NombreDelServicio;
    }

    public double getPrecioDelServicio() {
        return PrecioDelServicio;
    }

    public void setPrecioDelServicio(double PrecioDelServicio) {
        this.PrecioDelServicio = PrecioDelServicio;
    }

    public int getTiempoDeDuracionMin() {
        return TiempoDeDuracionMin;
    }

    public void setTiempoDeDuracionMin(int TiempoDeDuracionMin) {
        this.TiempoDeDuracionMin = TiempoDeDuracionMin;
    }

    public String getDescripcionDelServcio() {
        return DescripcionDelServcio;
    }

    public void setDescripcionDelServcio(String DescripcionDelServcio) {
        this.DescripcionDelServcio = DescripcionDelServcio;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Servicio{");
        sb.append("NombreDelServicio=").append(NombreDelServicio);
        sb.append(", PrecioDelServicio=").append(PrecioDelServicio);
        sb.append(", TiempoDeDuracionMin=").append(TiempoDeDuracionMin);
        sb.append(", DescripcionDelServcio=").append(DescripcionDelServcio);
        sb.append('}');
        return sb.toString();
    }
    
}